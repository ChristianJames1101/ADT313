<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$host = '127.0.0.1';  
$dbname = 'signup_db'; 
$username = 'root'; 
$password = ''; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

$email = $data['email'];
$password = password_hash($data['password'], PASSWORD_DEFAULT); 
$firstName = $data['firstName'];
$middleName = $data['middleName'];
$lastName = $data['lastName'];
$contactNo = $data['contactNo'];

$sql = "INSERT INTO users (email, password, firstName, middleName, lastName, contactNo) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $email, $password, $firstName, $middleName, $lastName, $contactNo);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'User registered successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'User registration failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>